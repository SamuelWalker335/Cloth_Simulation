﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using Unity.VisualScripting;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using static Unity.VisualScripting.Member;

public struct Spring{
    public Particle i;
    public Particle j;
    public float ks;
    public float kd;
    public float restLength;
}

public class ClothSimulation : MonoBehaviour
{
    public bool verlet = true;
    public bool genMesh = true;
    public float spacingBetweenParticles = 1;
    public bool breakOnDistance = true;
    public float breakDist;
    public float clickRadius;
    public int clothWidth = 10;
    public int clothHeight = 10;
    public GameObject cloth;
    public GameObject particleModel;

    public float particleMass = .2f;

    public List<Spring> springList = new List<Spring>();
    public List<GameObject> particles = new List<GameObject>();
    public GameObject[,] newParticles;

    public List<GameObject> renderedSprings = new List<GameObject>();
    public GameObject springRenderer;
    public GameObject springHolder;

    Vector3[] particlePos;
    int[] triangles;

    public Vector3 gravity1 = new Vector3(0, -9.8f, 0);
    public bool ActivateWind = false;
    public int windStrength = 10;
    public Vector3 wind = new Vector3(-1f,0,-1f);

    public float environmentalDrag = 0;

    Mesh mesh;


    //spring stuff
    public float ks = 20f;
    public float kd = 5f;
    public float restLength = 1f;

    // Start is called before the first frame update
    void Start()
    {
        newParticles = new GameObject[clothWidth+1,clothHeight+1];
        CreateParticleNetwork();
        GenerateSprings();
        
    }
    
    //create a network of particles
    public void CreateParticleNetwork() {
        //destroy all current particles
        for (int i = 0; i < particles.Count; i++) {
            Destroy(particles[i]);
        }
        particles.Clear();

        //create network of particles
        for (int y = 0; y <= clothHeight; y++)
        {
            for (int x = 0; x <= clothWidth; x++)
            {
                Vector3 pos = new Vector3(x * spacingBetweenParticles, (clothHeight - y) * spacingBetweenParticles, 0);
                particleModel.GetComponent<Particle>().pos = pos;
                GameObject newParticle = Instantiate(particleModel, pos, Quaternion.identity, cloth.transform);

                newParticle.GetComponent<Particle>().pos = newParticle.transform.position;
                newParticle.GetComponent<Particle>().Lpos = newParticle.transform.position;
                newParticle.GetComponent<Particle>().force = new Vector3(0, 0, 0);
                newParticle.GetComponent<Particle>().vel = new Vector3(0, 0, 0);
                newParticle.GetComponent<Particle>().mass = particleMass;
                if (y == 0)// && x == clothWidth-1 || y==0 && x ==0)
                {
                    newParticle.GetComponent<Particle>().locked = true;
                }
                particles.Add(newParticle);
                newParticles[x,y] = newParticle;

            }

        }

        //mesh stuff
        mesh = new Mesh();
        GetComponent<MeshFilter>().mesh = mesh;
        particlePos = new Vector3[particles.Count];


    }

    public void GenerateSprings()
    {
        /*
         * Structural: each particle [i,j] is connected to (up to) four particles via structural connections: [i,j+1], [i,j−1], [i+1,j], [i−1,j]
         * Shear: each particle [i,j] is connected to (up to) four particles via shear connections: [i+1,j+1], [i+1,j−1], [i−1,j−1], [i−1,j+1]
         * Flexion: each particle [i,j] is connected to (up to) four particles via flexion connections: [i,j+2], [i,j−2], [i+2,j], [i−2,j].
         */

        for (int y = 0; y <= clothHeight; y++)
        {
            for (int x = 0; x <= clothWidth; x++)
            {
                //check structural and connect
                AddStructural(x,y);
                //check shear and connect
                AddShear(x,y);
                //check flexion and connect
                AddFlexion(x,y);
            }

        }
    }
    //functioning as intended
    void AddStructural(int x, int y) {

        if (x + 1 <= clothWidth) {
           
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x+1, y].GetComponent<Particle>();
            if (!CheckIfSpring(s)) {
                print(x+","+ y + "->" + (x + 1) + "," + y);
                springList.Add(s);
            }
               
        }
        if (x-1 >= 0)
        {
            
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x-1, y].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(x + "," + y + "->" + (x - 1) + "," + y);
                springList.Add(s);
            }
        }
        if (y-1 >= 0)
        {
            
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x, y-1].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(x + "," + y + "->" + x + "," + (y-1));
                springList.Add(s);
            }
        }
        if (y+1 <= clothHeight)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x, y+1].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(x + "," + y + "->" + x + "," + (y +1));
                springList.Add(s);
            }
        }
    }

    //* Shear: each particle [i,j] is connected to (up to) four particles via shear connections: [i+1,j+1], [i+1,j−1], [i−1,j−1], [i−1,j+1]
    void AddShear(int x, int y) {

        if (x + 1 <= clothWidth && y+1 <= clothHeight)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x + 1, y + 1].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(s.i.pos + "->" + s.j.pos);
                springList.Add(s);
            }
        }
        if (x - 1 >= 0 && y+1 <= clothHeight)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x -1, y + 1].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(s.i.pos + "->" + s.j.pos);
                springList.Add(s);
            }
        }
        if (x - 1 >= 0 && y-1 >= 0)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x - 1, y-1].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(s.i.pos + "->" + s.j.pos);
                springList.Add(s);
            }
        }
        if (x + 1 <= clothWidth && y-1 >=0)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = restLength;
            s.j = newParticles[x + 1, y - 1].GetComponent<Particle>();
            if (!CheckIfSpring(s))
            {
                print(s.i.pos + "->" + s.j.pos);
                springList.Add(s);
            }
        }

    }

    // Flexion: each particle [i,j] is connected to (up to) four particles via flexion connections: [i,j+2], [i,j−2], [i+2,j], [i−2,j].
    void AddFlexion(int x, int y)
    {

        if (x + 2 <= clothWidth)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = 2f * restLength;
            s.j = newParticles[x+2, y].GetComponent<Particle>();
            springList.Add(s);
        }
        if (x - 2 >= 0)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = 2f * restLength;
            s.j = newParticles[x-2, y].GetComponent<Particle>();
            springList.Add(s);
        }
        if (y - 2 >= 0)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = 2f* restLength;
            s.j = newParticles[x, y-2].GetComponent<Particle>();
            springList.Add(s);
        }
        if (y + 2 <= clothHeight)
        {
            Spring s = new Spring();
            s.i = newParticles[x, y].GetComponent<Particle>();
            s.ks = ks;
            s.kd = kd;
            s.restLength = 2f*restLength;
            s.j = newParticles[x, y+2].GetComponent<Particle>();
            springList.Add(s);
        }
    }

    //check if a spring already exists
    bool CheckIfSpring(Spring s) {
        for (int i = 0; i < springList.Count; i++) {
            if (springList[i].i == s.j && springList[i].j == s.i) {
                //print("SAME SPRING");
                return true;
            }
        }
        return false;
        
    }

    //make springs visible
    public void renderSprings(Spring s, GameObject p) {

        GameObject newRenderedSpring = Instantiate(springRenderer, s.i.pos, Quaternion.identity, p.transform);
        newRenderedSpring.GetComponent<LineRenderer>().SetPosition(0, s.i.pos);
        newRenderedSpring.GetComponent<LineRenderer>().SetPosition(1, s.j.pos);
        renderedSprings.Add(newRenderedSpring);

    }
   
    // Update is called once per frame
    void FixedUpdate()
    {
        if (ActivateWind) {
            wind = new Vector3(Mathf.PerlinNoise(Time.time, 0) * windStrength, 0,0);
        }
      
        
        CalculateSpringForce();
        if (verlet)
        {
            Verlet();
        }
        else{
            SymplecticEuler();
        }
        

        for (int i =0; i< particles.Count; i++) {
            //print(particles[i].GetComponent<Particle>().vel);
            particles[i].transform.position = particles[i].GetComponent<Particle>().pos;
            //add to mesh array
            particlePos[i] = particles[i].GetComponent<Particle>().pos;
            //print(particles[i].GetComponent<Particle>().pos);
        }
        for (int i = 0; i < springList.Count; i++) {
            if (springList[i].i == null || springList[i].j == null) { 
                springList.RemoveAt(i);
            }
            if (breakOnDistance) {
                if (Vector3.Distance(springList[i].i.pos, springList[i].j.pos) >= breakDist)
                {
                    springList.RemoveAt(i);
                }
            }
            
        }

        if (genMesh)
        {
            GenerateMesh();
        }
        else {
            mesh.Clear();
        }
    }

    //symplectic Euler for movement of particles
    void SymplecticEuler()
    {
        List<Vector3> newVelocities = new List<Vector3>();
        List<Vector3> newPositions = new List<Vector3>();
        print("Euler");
        for (int i = 0; i < particles.Count; i++)
        {
            Vector3 vNew;
            Vector3 xNew;

            //print(particles[i].GetComponent<Particle>().pos);
            vNew = particles[i].GetComponent<Particle>().vel + (Time.deltaTime * (particles[i].GetComponent<Particle>().force / particles[i].GetComponent<Particle>().mass));
            xNew = particles[i].GetComponent<Particle>().pos + (Time.deltaTime * vNew);
            //print(particles[i].GetComponent<Particle>().vel);


            newVelocities.Add(vNew);
            newPositions.Add(xNew);
        }

        for (int i = 0; i < particles.Count; i++)
        {
            if (particles[i].GetComponent<Particle>().locked == false)
            {
                //set the last position to current pos/vel
                particles[i].GetComponent<Particle>().Lpos = particles[i].GetComponent<Particle>().pos;
                particles[i].GetComponent<Particle>().Lvel = particles[i].GetComponent<Particle>().vel;
                //set current pos to new pos/vel
                particles[i].GetComponent<Particle>().vel = newVelocities[i];
                particles[i].GetComponent<Particle>().pos = newPositions[i];
            }


        }

    }

    //verlet integration for movement of particles
    void Verlet() {
        List<Vector3> newVelocities = new List<Vector3>();
        List<Vector3> newPositions = new List<Vector3>();

        print("Verlet");
        for (int i = 0; i < particles.Count; i++)
        {
            Vector3 vNew;
            Vector3 xNew;
            //if in initial position use symplectic euler
            if (Time.time <= 0)
            {
                //print(particles[i].GetComponent<Particle>().pos);
                vNew = particles[i].GetComponent<Particle>().vel + (Time.deltaTime * (particles[i].GetComponent<Particle>().force / particles[i].GetComponent<Particle>().mass));
                xNew = particles[i].GetComponent<Particle>().pos + (Time.deltaTime * vNew);
                //print(particles[i].GetComponent<Particle>().vel);
            }
            //otherwise use verlet
            else
            {
                //print(particles[i].GetComponent<Particle>().pos);
                xNew = (2.0f * particles[i].GetComponent<Particle>().pos) - particles[i].GetComponent<Particle>().Lpos + ((particles[i].GetComponent<Particle>().force / particles[i].GetComponent<Particle>().mass) * Time.deltaTime * Time.deltaTime);
                vNew = (xNew - particles[i].GetComponent<Particle>().Lpos) / (2.0f * Time.deltaTime);

            }

            newVelocities.Add(vNew);
            newPositions.Add(xNew);
        }

        for (int i = 0; i < particles.Count; i++)
        {
            if (particles[i].GetComponent<Particle>().locked == false)
            {
                //set the last position to current pos/vel
                particles[i].GetComponent<Particle>().Lpos = particles[i].GetComponent<Particle>().pos;
                particles[i].GetComponent<Particle>().Lvel = particles[i].GetComponent<Particle>().vel;
                //set current pos to new pos/vel
                particles[i].GetComponent<Particle>().vel = newVelocities[i];
                particles[i].GetComponent<Particle>().pos = newPositions[i];
            }


        }
    }

    //spring force, gravity, environmental drag, and wind force calculations
    void CalculateSpringForce()
    {

        for (int i = 0; i < springList.Count; i++)
        {
            springList[i].i.force = (-environmentalDrag * springList[i].i.vel) + (gravity1 * springList[i].i.mass) + (wind * springList[i].i.mass);
            springList[i].j.force = (-environmentalDrag * springList[i].j.vel) + (gravity1 * springList[i].j.mass) + (wind * springList[i].j.mass);
        }

        for (int i = 0; i < springList.Count; i++){
            Vector3 springForce = springList[i].ks * (springList[i].restLength - Vector3.Distance(springList[i].i.pos, springList[i].j.pos)) * Vector3.Normalize(springList[i].i.pos - springList[i].j.pos);
            //					double * double((vector-vector)           dot           vector                       ) * normalized vector
            Vector3 damperForce = -springList[i].kd * Vector3.Dot((springList[i].i.vel - springList[i].j.vel), Vector3.Normalize(springList[i].i.pos - springList[i].j.pos)) * Vector3.Normalize(springList[i].i.pos - springList[i].j.pos);

            Vector3 iTotalForce = springForce + damperForce;
            Vector3 jTotalForce = -springForce - damperForce;

            //add spring & damper force
            springList[i].i.force += iTotalForce;
            springList[i].j.force += jTotalForce;
        }
    }

    void GenerateMesh() {
        triangles = new int[clothWidth * clothHeight * 6];
        
        //generate mesh triangles
        int vertIndex = 0;
        int triIndex = 0;
        for (int i = 0; i < clothHeight; i++) {
            for (int j = 0; j < clothWidth; j++) {
                triangles[triIndex + 0] = vertIndex;
                triangles[triIndex + 1] = vertIndex + 1;
                triangles[triIndex + 2] = vertIndex + clothWidth + 1;
                triangles[triIndex + 3] = vertIndex + 1;
                triangles[triIndex + 4] = vertIndex + clothWidth + 2;
                triangles[triIndex + 5] = vertIndex + clothWidth + 1;

                vertIndex++;
                triIndex += 6;
            }
            vertIndex++;
        }

        mesh.vertices = particlePos;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();
    }
}
