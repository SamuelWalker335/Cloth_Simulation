using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particle : MonoBehaviour
{
    public Vector3 pos = new Vector3(0,0,0);
    public Vector3 vel = new Vector3(0, 0, 0);
    public Vector3 force = new Vector3(0, 0, 0);
    public float mass = 1;
    public bool locked = false;

    public Vector3 Lpos = new Vector3(0, 0, 0);
    public Vector3 Lvel = new Vector3(0, 0, 0);

    //public LineRenderer line;
    public ClothSimulation cloth;
    
    // Start is called before the first frame update
    void Awake()
    {
        cloth = gameObject.GetComponentInParent<ClothSimulation>();
        //line = GetComponent<LineRenderer>();
    }
    //if click on particle remove it (to simulate cutting)
    public void DestroyParticle()
    {
        print("clicked particle");
        for (int i = 0; i < cloth.particles.Count; i++)
        {
            if (cloth.particles[i] == gameObject)
            {
                cloth.particles.RemoveAt(i);
                break;
            }
        }
        Destroy(gameObject);

        
        //if (Input.GetMouseButton(2)){
        //    pos = Input.mousePosition;
        //}

    }
}
