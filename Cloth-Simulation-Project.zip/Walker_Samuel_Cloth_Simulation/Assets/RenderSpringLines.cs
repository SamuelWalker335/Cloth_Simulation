using System.Collections.Generic;
using UnityEngine;

public class RenderSpringLines : MonoBehaviour
{
    // Draws a line from "startVertex" var to the curent mouse position.
    public Material mat;
    public GameObject clothOBJ;
    ClothSimulation cloth;
    List<Vector3> vertices = new List<Vector3>();

    void Start()
    {
        cloth = clothOBJ.GetComponent<ClothSimulation>();

    }

    void Update()
    {
        vertices.Clear();
        for (int i = 0; i < cloth.springList.Count; i++)
        {
            vertices.Add(cloth.springList[i].i.pos);
            vertices.Add(cloth.springList[i].j.pos);
        }
    }

    void OnPostRender()
    {
        if (!mat)
        {
            Debug.LogError("Please Assign a material on the inspector");
            return;
        }
        for (int i = 0; i < vertices.Count - 1; i++)
        {
            GL.PushMatrix();
            mat.SetPass(0);

            GL.Begin(GL.LINES);
            GL.Color(Color.red);
            GL.Vertex(vertices[i]);
            GL.Vertex(vertices[i + 1]);
            GL.End();

            GL.PopMatrix();

        }

    }
}