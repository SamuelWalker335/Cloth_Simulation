using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickDestroyParticles : MonoBehaviour
{
    public ClothSimulation cloth;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0)) {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit[] hits = Physics.SphereCastAll(ray, cloth.clickRadius, Mathf.Infinity);

            foreach (RaycastHit hit in hits)
            {
                GameObject obj = hit.collider.gameObject;
                obj.GetComponent<Particle>().DestroyParticle();
            }
        }
       
    }
}
