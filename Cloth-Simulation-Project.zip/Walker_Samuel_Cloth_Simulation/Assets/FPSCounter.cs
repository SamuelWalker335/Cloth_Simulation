using UnityEngine;
using TMPro;

public class FPSCounter : MonoBehaviour
{

    public TextMeshProUGUI fpsText; // reference to the TextMeshProUGUI component that will display the FPS count
    public float updateInterval = 0.5f; // time interval between FPS count updates

    private float deltaTime; // time elapsed since last FPS count update
    private float timeLeft; // time left until the next FPS count update

    private void Start()
    {
        fpsText = GetComponent<TextMeshProUGUI>();
        timeLeft = updateInterval; // set the time left until the next FPS count update to the interval time
    }

    private void Update()
    {
        deltaTime += (Time.unscaledDeltaTime - deltaTime) * 0.1f; // calculate time elapsed since last FPS count update
        timeLeft -= Time.unscaledDeltaTime; // calculate time left until the next FPS count update
        if (timeLeft <= 0f)
        { // if it's time to update the FPS count display
            float fps = 1.0f / deltaTime; // calculate FPS count
            fpsText.text = string.Format("{0:0.} FPS", fps); // display FPS count in the TextMeshProUGUI component
            timeLeft = updateInterval; // reset the time left until the next FPS count update
            deltaTime = 0f; // reset the time elapsed since last FPS count update
        }
    }
}
