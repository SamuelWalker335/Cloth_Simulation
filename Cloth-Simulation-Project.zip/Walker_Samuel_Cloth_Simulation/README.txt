Samuel Walker
V00896718
Cloth Simulation

--------------------------------
Unity Version: 2021.3.17f1
-------------------------------

Controls:
-------------------
wsad: move
hold right click: rotate camera
left click on cloth: rip cloth
-----------------------------

Parameters:
-------------------------
On cloth object, edit parameters within the "Cloth Simulation" script

boolean Verlet: changes between verlet and symplectic Euler
boolean Gen Mesh: generates a mesh between particles
boolean Break On Distance: turns on the emergent ripping

 